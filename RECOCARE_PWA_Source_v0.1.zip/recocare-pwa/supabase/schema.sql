-- RECOCARE initial Supabase schema
-- Run in Supabase SQL Editor. Review with a qualified security professional before launch.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role text not null check (role in ('patient','provider','admin')),
  created_at timestamptz not null default now()
);

-- Create a profile automatically when Supabase Auth creates a user.
-- Public metadata is restricted to patient/provider roles; admin is assigned manually by SQL.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_role text;
begin
  requested_role := coalesce(new.raw_user_meta_data ->> 'role', 'patient');
  if requested_role not in ('patient','provider') then
    requested_role := 'patient';
  end if;
  insert into public.profiles (id, full_name, phone, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'full_name',''), 'RECOCARE user'),
    nullif(new.raw_user_meta_data ->> 'phone',''),
    requested_role
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_recocare on auth.users;
create trigger on_auth_user_created_recocare
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.provider_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  business_name text not null,
  service text not null check (service in ('Nursing / Home Nursing','Physiotherapy','Post-operative Care','Medical Equipment')),
  locality text not null check (locality in ('Jayanagar','JP Nagar','Banashankari','BTM Layout','Arekere','Hulimavu','Bannerghatta Road','Electronic City')),
  contact_phone text not null,
  description text,
  verification_status text not null default 'pending' check (verification_status in ('pending','approved','rejected','suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id),
  provider_id uuid references public.profiles(id),
  service text not null check (service in ('Nursing / Home Nursing','Physiotherapy','Post-operative Care','Medical Equipment')),
  locality text not null check (locality in ('Jayanagar','JP Nagar','Banashankari','BTM Layout','Arekere','Hulimavu','Bannerghatta Road','Electronic City')),
  preferred_date date not null,
  preferred_time text not null check (preferred_time in ('Morning','Afternoon','Evening')),
  patient_name text not null,
  phone text not null,
  notes text,
  status text not null default 'pending' check (status in ('pending','approved','completed','cancelled','rejected')),
  created_at timestamptz not null default now()
);

create index if not exists provider_profiles_locality_service_idx
  on public.provider_profiles(locality, service, verification_status);
create index if not exists bookings_patient_created_idx
  on public.bookings(patient_id, created_at desc);
create index if not exists bookings_provider_created_idx
  on public.bookings(provider_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.provider_profiles enable row level security;
alter table public.bookings enable row level security;

-- SECURITY DEFINER helper avoids recursive RLS checks when policies test admin status.
create or replace function public.is_recocare_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Profiles: users can read/update their own basic profile. Admin can read all.
create policy "profiles_read_own_or_admin" on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_recocare_admin());

create policy "profiles_insert_self" on public.profiles
for insert to authenticated
with check (id = auth.uid() and role in ('patient','provider'));

create policy "profiles_update_self_basic" on public.profiles
for update to authenticated
using (id = auth.uid())
with check (id = auth.uid() and role in ('patient','provider'));

-- Public can view approved provider cards. Owners can view their own; admin can view all.
create policy "provider_profiles_read_approved_owner_admin" on public.provider_profiles
for select to anon, authenticated
using (
  verification_status = 'approved'
  or user_id = auth.uid()
  or public.is_recocare_admin()
);

create policy "provider_profiles_insert_owner" on public.provider_profiles
for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (select 1 from public.profiles me where me.id=auth.uid() and me.role='provider')
  and verification_status = 'pending'
);

create policy "provider_profiles_admin_update" on public.provider_profiles
for update to authenticated
using (public.is_recocare_admin())
with check (public.is_recocare_admin());

-- Bookings: patients create and view their own; assigned provider sees assigned requests; admin manages all.
create policy "bookings_patient_insert" on public.bookings
for insert to authenticated
with check (
  patient_id = auth.uid()
  and status = 'pending'
  and provider_id is null
  and exists (select 1 from public.profiles me where me.id=auth.uid() and me.role='patient')
);

create policy "bookings_read_patient_provider_admin" on public.bookings
for select to authenticated
using (
  patient_id = auth.uid()
  or provider_id = auth.uid()
  or public.is_recocare_admin()
);

create policy "bookings_admin_update" on public.bookings
for update to authenticated
using (public.is_recocare_admin())
with check (public.is_recocare_admin());

-- IMPORTANT ADMIN SETUP:
-- Create your first account through the app, then run this in SQL Editor:
-- update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
-- Never expose the Supabase service_role key in the browser or in this repository.
